# pre_onboarding_assignment_FAST_API
7팀 기업과제 3번 FAST API

팀원 : 김태호, 임채은, 조하진, 김석재, 안정이

Flask_app을 사용하여 로컬 호스트를 통해 STS 결과를 확인할 수 있는 코드를 작성하였습니다.
